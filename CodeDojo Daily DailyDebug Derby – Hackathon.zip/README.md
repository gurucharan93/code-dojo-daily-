# CodeDojo Daily — Clean Campus — crisp blue and white academic look

A React/Vite coding-challenge web-app prototype based on the uploaded DailyDebug Derby brief. Includes dashboard stats, daily challenge, code workspace mock runner, challenge filters, team leaderboard, squad area and streak calendar.

## Run locally
- Install Node.js 18+
- `npm install`
- `npm run dev`
- Open the Vite local URL shown in terminal.

## Demo note
Test evaluation is mocked for presentation. This prototype does not securely execute arbitrary code. To make a production submission, integrate isolated server-side code execution and persistent database/authentication.
